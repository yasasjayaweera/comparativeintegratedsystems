// React Native Navigation Drawer
// https://aboutreact.com/react-native-navigation-drawer/
import React, { useState } from 'react';
import {
  Button,
  TextInput,
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView
} from 'react-native';

import AsyncStorage from '@react-native-community/async-storage';


const FirstPage  = props => {
    let [userEmail, setUserEmail] = useState('');
    let [userPassword, setUserPassword] = useState('');
    let [errortext, setErrortext] = useState('');
  
    const handleSubmitPress = () => {
      setErrortext('');
      if (!userEmail) {
        alert('Please fill Email');
        return;
      }
      if (!userPassword) {
        alert('Please fill Password');
        return;
      }
      
      if (userEmail== 'yasas.j@sliit.lk' && userPassword=='123') {
            AsyncStorage.setItem('user_name', userEmail);
            
            props.navigation.navigate('SecondPage');
          } else {
            setErrortext('Please check your email id or password');
            
          }
    };
          return (
            <View style={styles.mainBody}>  
             
                <View style={{ marginTop: 100 }}>
                   <View style={styles.SectionStyle}>
                      <TextInput
                        style={styles.inputStyle}
                        onChangeText={UserEmail => setUserEmail(UserEmail)}
                        underlineColorAndroid="#FFFFFF"
                        placeholder="Enter Email"
                        placeholderTextColor="#F6F6F7"
                        autoCapitalize="none"
                        keyboardType="email-address"                        
                        blurOnSubmit={false}
                      />
                    </View>
                    <View style={styles.SectionStyle}>
                      <TextInput
                        style={styles.inputStyle}
                        onChangeText={UserPassword => setUserPassword(UserPassword)}
                        underlineColorAndroid="#FFFFFF"
                        placeholder="Enter Password"
                        placeholderTextColor="#F6F6F7"
                        keyboardType="default"
                        blurOnSubmit={false}
                        secureTextEntry={true}
                      />
                    </View>
                    {errortext != '' ? (
                      <Text style={styles.errorTextStyle}> {errortext} </Text>
                    ) : null}
                    <TouchableOpacity
                      style={styles.buttonStyle}
                      activeOpacity={0.5}
                      onPress={handleSubmitPress}>
                      <Text style={styles.buttonTextStyle}>LOGIN</Text>
                    </TouchableOpacity>
                    <Text
                      style={styles.registerTextStyle}
                      onPress={() => props.navigation.navigate('ThirdPage')}>
                      New Here ? Register
                    </Text>                  
                </View>            
            </View>
          );
        };
    
        export default FirstPage ;
        const styles = StyleSheet.create({
            mainBody: {
              flex: 1,
              justifyContent: 'center',
              backgroundColor: '#307ecc',
            },
            SectionStyle: {
              flexDirection: 'row',
              height: 40,
              marginTop: 20,
              marginLeft: 35,
              marginRight: 35,
              margin: 10,
            },
            buttonStyle: {
              backgroundColor: '#7DE24E',
              borderWidth: 0,
              color: '#FFFFFF',
              borderColor: '#7DE24E',
              height: 40,
              alignItems: 'center',
              borderRadius: 30,
              marginLeft: 35,
              marginRight: 35,
              marginTop: 20,
              marginBottom: 20,
            },
            buttonTextStyle: {
              color: '#FFFFFF',
              paddingVertical: 10,
              fontSize: 16,
            },
            inputStyle: {
              flex: 1,
              color: 'white',
              paddingLeft: 15,
              paddingRight: 15,
              borderWidth: 1,
              borderRadius: 30,
              borderColor: 'white',
            },
            registerTextStyle: {
              color: '#FFFFFF',
              textAlign: 'center',
              fontWeight: 'bold',
              fontSize: 14,
            },
            errorTextStyle: {
              color: 'red',
              textAlign: 'center',
              fontSize: 14,
            },
          });        
        



